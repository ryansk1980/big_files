#define QT_FEATURE_speechd -1
