#define QT_FEATURE_flite -1
#define QT_FEATURE_flite_alsa -1
